This folder contains the Solidworks part and assembly file for viewing/3D printing the rewarming device components. 

Author: Rui Xu
Date: 07/20/2024


%% Assemblies
DeviceAssembly.SLDASM - device assembly file, references may need to be updated
NUNC 1.8 Cryo Vial Assembly.SLDASM - assembly file obtained from: https://grabcad.com/library/nunc-1-8-ml-cryo-vial-1


%% Purchased Components
Transducer.SLDPRT - based on the element purchased from PICeramics (needs to be purchased)
oring.SLDPRT - o-ring purchased from RS-PRO (stock number 196-4928)
Two M6 nuts and bolts (20 mm)
BNC cable, soldered to the internal and external transducer electrodes with lead-free solder
Thermocouple, epoxied to the external transducer electrode with Araldite epoxy
Polyutherane foam (CRC, Hormsham, PA, USA)
Araldite + tungsten powder (Huntsman Advanced Materials, Cambridge, UK) acoustic matching layer
 	- applied to the internal surface and machined to the desired thickness after cured


%% 3D-printed components
CryovialHolderV2.SLDPRT - slip-fit cryovial mount (also slip fit onto the top of the transducer)
LiquidTxholderV3.SLDPRT - used in conjunction with the o-ring and grease to create an external seal with the transducer
TxContainer.SLDPRT - larger volume used to enclose the parts above and with polyutherane foam (CRC)
TxWireClamp.SLDPRT - used with the M6 nuts and bolts to secure the thermocouple + BNC cable (exit from port in TxContainer) for strain relief.

3-D prints were made with an Ultimaker CURA system using PLA and 20% infill. 